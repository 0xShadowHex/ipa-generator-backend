/**
 * Notification Bridge for iOS WebView
 * 
 * This module provides a JavaScript interface to schedule native iOS notifications
 * through the WebView JavaScript bridge.
 */

/**
 * Schedule a native iOS notification
 * 
 * @param {number} timeFromNow - Delay in seconds before showing the notification
 * @param {string} message - The notification message text to display
 * 
 * @example
 * // Schedule a notification for 5 seconds from now
 * push(5, "Hello from WebView!");
 * 
 * @example
 * // Schedule a notification for 30 seconds from now
 * push(30, "This is a delayed notification");
 */
function push(timeFromNow, message) {
    // Validate inputs
    if (typeof timeFromNow !== 'number' || timeFromNow < 0) {
        console.error('Invalid delay: must be a positive number (seconds)');
        return false;
    }
    
    if (typeof message !== 'string' || message.trim() === '') {
        console.error('Invalid message: must be a non-empty string');
        return false;
    }
    
    // Prepare the notification payload
    const notificationPayload = {
        delay: timeFromNow,
        message: message.trim(),
        timestamp: new Date().toISOString()
    };
    
    try {
        // Check if the native bridge is available
        if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.notificationHandler) {
            // iOS WKWebView bridge - call the native Swift handler
            window.webkit.messageHandlers.notificationHandler.postMessage(notificationPayload);
            console.log(`Notification scheduled: "${message}" in ${timeFromNow} seconds`);
            return true;
        } else if (window.notificationHandler) {
            // Fallback for alternative bridge implementations
            window.notificationHandler.scheduleNotification(JSON.stringify(notificationPayload));
            console.log(`Notification scheduled: "${message}" in ${timeFromNow} seconds`);
            return true;
        } else {
            // Development fallback - log to console when native bridge is not available
            console.warn('Native notification bridge not available. Running in development mode.');
            console.log(`[NOTIFICATION SIMULATION] Scheduled for ${timeFromNow}s: "${message}"`);
            
            // Simulate the notification with a browser alert for testing
            setTimeout(() => {
                alert(`Notification: ${message}`);
            }, timeFromNow * 1000);
            
            return true;
        }
    } catch (error) {
        console.error('Error scheduling notification:', error);
        return false;
    }
}

// Export for module systems if needed
if (typeof module !== 'undefined' && module.exports) {
    module.exports = { push };
}
