/**
 * Main Application Logic
 * 
 * Handles UI interactions and logging for the WebView notification demo
 */

// Log utility
const logger = {
    log: function(message, type = 'info') {
        const logElement = document.getElementById('log');
        const timestamp = new Date().toLocaleTimeString();
        const entry = document.createElement('div');
        entry.className = `log-entry ${type}`;
        entry.innerHTML = `<span class="timestamp">[${timestamp}]</span> ${message}`;
        logElement.appendChild(entry);
        logElement.scrollTop = logElement.scrollHeight;
    },
    
    success: function(message) {
        this.log(message, 'success');
    },
    
    error: function(message) {
        this.log(message, 'error');
    },
    
    info: function(message) {
        this.log(message, 'info');
    }
};

// Initialize the application when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    logger.info('Application initialized');
    
    // Get DOM elements
    const delayInput = document.getElementById('delayInput');
    const messageInput = document.getElementById('messageInput');
    const scheduleBtn = document.getElementById('scheduleBtn');
    const testBtn = document.getElementById('testBtn');
    
    // Schedule notification button handler
    scheduleBtn.addEventListener('click', function() {
        const delay = parseInt(delayInput.value);
        const message = messageInput.value.trim();
        
        // Validate inputs
        if (isNaN(delay) || delay < 1) {
            logger.error('Invalid delay: must be at least 1 second');
            return;
        }
        
        if (message === '') {
            logger.error('Message cannot be empty');
            return;
        }
        
        // Schedule the notification
        const success = push(delay, message);
        
        if (success) {
            logger.success(`Notification scheduled: "${message}" in ${delay} second(s)`);
        } else {
            logger.error('Failed to schedule notification');
        }
    });
    
    // Quick test button handler
    testBtn.addEventListener('click', function() {
        const testMessage = 'Quick test notification!';
        const success = push(3, testMessage);
        
        if (success) {
            logger.success(`Quick test scheduled: "${testMessage}" in 3 seconds`);
        } else {
            logger.error('Failed to schedule quick test notification');
        }
    });
    
    // Allow Enter key to schedule notification
    messageInput.addEventListener('keypress', function(event) {
        if (event.key === 'Enter') {
            scheduleBtn.click();
        }
    });
    
    logger.info('UI event listeners attached');
});
